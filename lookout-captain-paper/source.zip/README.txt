The Lookout and the Captain — LaTeX source

Build with Tectonic 0.17.0:
SOURCE_DATE_EPOCH=1788825600 FORCE_SOURCE_DATE=1 tectonic main.tex

All required figures and bibliography are included. For the saved-data
analysis, editable template, and experiment code, see:
https://github.com/kortexa-ai/legolm.paper/tree/main/reproductions/lookout-captain
